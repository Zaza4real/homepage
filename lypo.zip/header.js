// Shared header behavior - CLEAN & SIMPLE VERSION
(() => {
  "use strict";
  
  const AUTH_TOKEN_KEY = "lypo_token_v1";
  
  // Cache authentication state
  const token = localStorage.getItem(AUTH_TOKEN_KEY) || "";
  const isAuthed = !!token;
  
  // Cache DOM queries
  const authBtn = document.querySelector(".headerAuthBtn");
  const btnLabel = authBtn?.querySelector(".btnLabel");
  const logoLink = document.querySelector(".logoWrap");
  const tabs = document.querySelectorAll(".tabBtn");
  
  // Make logo always go to homepage
  if (logoLink) logoLink.setAttribute("href", "index.html");
  
  // Detect current page
  const path = location.pathname.toLowerCase();
  const page = path.split('/').pop() || 'index.html';
  const isDashboard = page === "dashboard.html";
  const isAuth = page === "auth.html";
  const isHome = page === "index.html" || page === "" || path === "/";
  
  // Page-to-tab mapping
  const pageTabMap = {
    "features.html": '[data-href="features.html"]',
    "support.html": '[data-href="support.html"]',
    "blog.html": '[data-href="blog.html"]',
    "about.html": '[data-href="about.html"]'
  };
  
  // Remove all active states first
  tabs.forEach(tab => tab.classList.remove("isActive"));
  
  // Highlight current page tab
  const tabSelector = pageTabMap[page];
  if (tabSelector) {
    const activeTab = document.querySelector(tabSelector);
    if (activeTab) activeTab.classList.add("isActive");
  } else if (isHome) {
    const toolsBtn = document.getElementById('toolsBtn');
    if (toolsBtn) toolsBtn.classList.add("isActive");
  }
  
  // Auth button setup
  if (authBtn && btnLabel) {
    const targetText = isAuthed ? "Dashboard" : "Login";
    const targetPage = isAuthed ? "dashboard.html" : "auth.html";
    
    if (btnLabel.textContent !== targetText) {
      btnLabel.textContent = targetText;
    }
    
    authBtn.classList.toggle("isActive", isAuthed && isDashboard);
    authBtn.classList.toggle("isActive", !isAuthed && isAuth);
    authBtn.setAttribute("data-target", targetPage);
    
    authBtn.addEventListener("click", (e) => {
      e.preventDefault();
      const target = authBtn.getAttribute("data-target");
      if (target) location.href = target;
    }, { passive: false, once: false });
  }
  
  // Tab navigation
  if (!isHome && tabs.length) {
    tabs.forEach((btn) => {
      if (btn.id === 'toolsBtn') return; // Skip Tools button
      
      btn.addEventListener("click", () => {
        const href = btn.getAttribute("data-href");
        if (href) {
          location.href = href;
        } else {
          const tab = btn.getAttribute("data-tab") || "home";
          location.href = `index.html?tab=${encodeURIComponent(tab)}`;
        }
      }, { passive: true });
    });
  }
  
  // Force style calculation
  if (authBtn) void authBtn.offsetHeight;
})();

// ========================================
// TOOLS DROPDOWN - WORKS ON DESKTOP + MOBILE
// ========================================

(function() {
  'use strict';
  
  const toolsBtn = document.getElementById('toolsBtn');
  const toolsMenu = document.getElementById('toolsMenu');
  
  if (!toolsBtn || !toolsMenu) {
    console.error('❌ Dropdown elements not found');
    return;
  }
  
  let isOpen = false;
  let lastToggleTime = 0;
  
  // SHOW MENU - NUCLEAR OPTION FOR MOBILE
  function show() {
    isOpen = true;
    
    // Step 1: Remove ALL attributes and classes
    toolsMenu.className = '';
    toolsMenu.removeAttribute('hidden');
    toolsMenu.removeAttribute('aria-hidden');
    
    // Step 2: Move to body (prevents parent clipping)
    if (toolsMenu.parentElement !== document.body) {
      console.log('📦 Moving menu to body');
      document.body.appendChild(toolsMenu);
    }
    
    // Step 3: Set styles using setAttribute (MOST aggressive method)
    toolsMenu.setAttribute('style', [
      'display: block !important',
      'visibility: visible !important',
      'opacity: 1 !important',
      'pointer-events: auto !important',
      'position: fixed !important',
      'left: 50% !important',
      'top: 80px !important',
      'margin-left: -150px !important',
      'z-index: 2147483647 !important',
      'width: 300px !important',
      'max-width: calc(100vw - 40px) !important',
      'background: rgba(20,20,30,0.98) !important',
      'border: 2px solid rgba(255,255,255,0.3) !important',
      'border-radius: 16px !important',
      'padding: 12px !important',
      'box-shadow: 0 20px 60px rgba(0,0,0,0.8) !important',
      'backdrop-filter: blur(20px) !important',
      '-webkit-backdrop-filter: blur(20px) !important',
      'overflow: visible !important'
    ].join('; '));
    
    toolsBtn.setAttribute('aria-expanded', 'true');
    
    // Force reflow
    void toolsMenu.offsetHeight;
    
    console.log('✅ Menu opened');
    console.log('📍 Menu styles set:', toolsMenu.style.cssText.substring(0, 100) + '...');
    
    // Verify it's visible
    const rect = toolsMenu.getBoundingClientRect();
    console.log('📐 Menu position:', {
      top: rect.top,
      left: rect.left,
      width: rect.width,
      height: rect.height
    });
    
    if (rect.width === 0 || rect.height === 0) {
      console.error('❌ Menu has no size! Check content.');
    } else {
      console.log('✅ Menu should be visible at position:', rect.top + 'px from top');
    }
  }
  
  // HIDE MENU
  function hide() {
    isOpen = false;
    toolsMenu.style.display = 'none';
    toolsMenu.style.visibility = 'hidden';
    toolsMenu.style.opacity = '0';
    toolsMenu.style.pointerEvents = 'none';
    toolsMenu.setAttribute('hidden', '');
    toolsBtn.setAttribute('aria-expanded', 'false');
    console.log('✅ Menu closed');
  }
  
  // TOGGLE with debounce (prevents double-firing)
  function toggle(e) {
    const now = Date.now();
    
    // Prevent double-firing within 300ms
    if (now - lastToggleTime < 300) {
      console.log('⏭️ Debounced - too soon');
      return;
    }
    
    lastToggleTime = now;
    
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    
    isOpen ? hide() : show();
  }
  
  // BOTH EVENTS - Debounced to prevent double-fire
  
  // Touch event (mobile)
  toolsBtn.addEventListener('touchend', function(e) {
    console.log('📱 Touch event');
    toggle(e);
  }, { passive: false });
  
  // Click event (desktop + mobile fallback)
  toolsBtn.addEventListener('click', function(e) {
    console.log('🖱️ Click event');
    toggle(e);
  }, false);
  
  // Close when clicking/tapping outside
  document.addEventListener('click', function(e) {
    if (isOpen && !toolsBtn.contains(e.target) && !toolsMenu.contains(e.target)) {
      hide();
    }
  }, true);
  
  // Also close on touch outside (for mobile)
  document.addEventListener('touchend', function(e) {
    if (isOpen && !toolsBtn.contains(e.target) && !toolsMenu.contains(e.target)) {
      hide();
    }
  }, { passive: true, capture: true });
  
  // Escape key to close
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && isOpen) {
      hide();
      toolsBtn.focus();
    }
  });
  
  // Initial state
  hide();
  
  console.log('✅ Dropdown ready - Universal mode (works on desktop + mobile)');
})();
